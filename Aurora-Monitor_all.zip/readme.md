# Aurora-Monitor
Eduational project - Fluxgate Magnetometer system to monitor nTesla changes in the earth's field 24/7
see construction notes in folder documentation and the primary paper published at https://doi.org/10.1088/1361-6552/aaacb2
This and other projects may be seen at www.schoolphysicsprojects.org

\Ian
